
buildscript {
    repositories {
        google()  // This includes the Google Maven repository
        mavenCentral()
    }
    dependencies {
        classpath ("com.android.tools.build:gradle:7.4.2") // or latest version
        classpath ("com.google.gms:google-services:4.4.2") // Google services plugin
    }}
    plugins {

        id("com.google.gms.google-services") version "4.4.2" apply false

    }


