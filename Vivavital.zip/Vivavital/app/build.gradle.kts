plugins {
    id("com.android.application")
    id("com.google.gms.google-services")


}

android {
    namespace = "com.example.vivavital"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.vivavital"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = org.gradle.api.JavaVersion.VERSION_17
        targetCompatibility = org.gradle.api.JavaVersion.VERSION_17
    }
    dependenciesInfo {
        includeInApk = true
        includeInBundle = true
    }
    buildToolsVersion = "33.0.1"
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.0.0")) // Slightly older stable version
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.android.gms:play-services-auth:21.1.1") // Downgraded for stability
    implementation("com.airbnb.android:lottie:6.3.0") // More stable version
    implementation("androidx.appcompat:appcompat:1.6.1") // Rolled back to stable
    implementation("com.google.android.material:material:1.9.0") // Matches AppCompat
    implementation("androidx.constraintlayout:constraintlayout:2.1.4") // Stable version
    implementation("androidx.navigation:navigation-fragment-ktx:2.6.0") // Added -ktx suffix
    implementation("androidx.navigation:navigation-ui-ktx:2.6.0") // Added -ktx suffix
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}