package com.example.vivavital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Medication extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medication);
    }
}